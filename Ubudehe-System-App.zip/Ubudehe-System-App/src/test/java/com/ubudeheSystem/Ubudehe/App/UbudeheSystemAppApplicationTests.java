package com.ubudeheSystem.Ubudehe.App;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UbudeheSystemAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
