<<<<<<< HEAD
![img_1.png](img_1.png)
=======
# ubudehe

Name: Jean Claude NIYIBIZI
ID: 20312
# The purpose of ubudehe system 

The Ubudehe system is a socio-economic categorization system implemented in Rwanda. Its purpose is to gather information about the income and living conditions of Rwandan citizens in order to effectively allocate resources and implement targeted development programs.
# Project requirement
# Functional Requirements
The system should have a login, signup and citizen view 
The system should allow administer to create account  
The system should be able to record citizenship 
 The system should be able update, delete and upload file 
The system should be able to download and delete reports.
The system should show the recorded citizenship  
The system should allow a user to login by using username and password.
# Non-Functional Requirements
Non-functional requirements are requirements that specifies criteria that can be used to judge the operation of a system.

Accuracy &Reliability: The System should fulfill the assigned task with failure-free.
aintainability: The system should be modified, maintainable, and ready for a correction
 Operability: The System should be able to operate under any Operating System and efficient to operate
# Project Plan:
# Project Objectives: 
a. Develop a comprehensive database system to store and manage individual socioeconomic information.
 b. Design an intuitive user interface for data entry and retrieval.
 c. Classify individuals into different wealth categories based on predefined criteria.
 d. Generate relevant report
# Project Phases:
Phase 1: Planning
# scope and objective
this project mainly will focus on record the Rwandan citizenship and categorizing them according to his /her income ubudehe system supposed to cover big size I focus on that due to the time   and knowledge 
the required resources that I was used for achieving this is personal computer, intelliJ IDEA, MySQL database, star UML and research on ubudehe current system.
# Phase 2: System Design and Development

Analyze existing data collection processes and determine system requirements.
Design the database structure to store socioeconomic information securely.
Develop the user interface for data entry, ensuring ease of use and data integrity.
# Phase 3:  Reporting

Create file containing all informatiomation related with cizenship  
Create reporting mechanisms to generate relevant insights and statistics.
Design visually appealing and user-friendly reports and dashboards.


# A database schema
 Adatabase schema is a logical blueprint or structure that defines the organization, layout, and relationships of a database system. It provides a framework for organizing and representing the data stored within the database.
 

![image](https://github.com/nclaude05/ubudehe/assets/50291475/d77613b9-ef1b-4939-9412-71039b1100cc)

User documentation 

User document 
The purpose of this document is to guide users on how to log in to the application using their credentials. This process ensures secure access to the application and its features. Please follow the steps below to successfully log in.

Before proceeding with the login process, ensure you have the following:

A registered account with the application.
Valid login credentials, including email and password.

Follow the steps below to log in to the application:

# Step 1: run ubudehe application

Open the ubudehe application on your device. The application icon should be visible on your home screen or in the application drawer.
![image](https://github.com/nclaude05/ubudehe/assets/50291475/6354075c-5155-4976-8165-b60ce24130bd)

 
# Step 2: Locate the Login Page

Upon launching the application, you will be directed to the login page. There is signup button will redirect you on signup page will fill all field you have after that redirect you to the signup page
  ![image](https://github.com/nclaude05/ubudehe/assets/50291475/a448616d-0613-41aa-9226-2e4d9961c034)

# Step 3: Enter email

In the designated field, enter your registered email. Be cautious of case sensitivity.
# Step 4: Enter Password

In the password field, enter your corresponding password. Pay attention to case sensitivity and ensure the password is entered correctly.
# Step 5: Submit Login Credentials

After entering your email and password, click or tap the "Login" button to submit your login credentials.
It will redirect you to view citizen 

# 6: Wait for Authentication
The application will validate your entered credentials against the stored user database. Please wait patiently while the application performs the authentication process.
# Step 7: Successful Login

If the entered credentials are correct, you will be successfully logged in to the application. The application will display the main dashboard or the landing page, providing access to its features and functionalities.
 
![image](https://github.com/nclaude05/ubudehe/assets/50291475/bd190ced-2c42-433c-9408-d1374d7a9e16)




# this is link  for deployement 

https://webtech-app-2.herokuapp.com/







>>>>>>> refs/remotes/origin/main
